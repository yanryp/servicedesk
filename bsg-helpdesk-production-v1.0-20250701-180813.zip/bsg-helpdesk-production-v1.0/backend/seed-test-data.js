const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function seedTestData() {
  try {
    // Get departments
    const itDept = await prisma.department.findFirst({ 
      where: { name: 'Information Technology' } 
    });
    const supportDept = await prisma.department.findFirst({ 
      where: { name: 'Dukungan dan Layanan' } 
    });

    if (!itDept || !supportDept) {
      console.log('❌ Departments not found');
      return;
    }

    console.log('📋 Found departments:');
    console.log(`- IT Department: ${itDept.name} (ID: ${itDept.id})`);
    console.log(`- Support Department: ${supportDept.name} (ID: ${supportDept.id})`);

    // Create IT categories
    const networkCategory = await prisma.category.upsert({
      where: { 
        departmentId_name: {
          departmentId: itDept.id,
          name: 'Network Issues'
        }
      },
      update: {},
      create: {
        name: 'Network Issues',
        departmentId: itDept.id
      }
    });

    // Create Banking categories  
    const kasdaCategory = await prisma.category.upsert({
      where: { 
        departmentId_name: {
          departmentId: supportDept.id,
          name: 'KASDA Support'
        }
      },
      update: {},
      create: {
        name: 'KASDA Support',
        departmentId: supportDept.id
      }
    });

    const bsgCategory = await prisma.category.upsert({
      where: { 
        departmentId_name: {
          departmentId: supportDept.id,
          name: 'BSGDirect Support'
        }
      },
      update: {},
      create: {
        name: 'BSGDirect Support', 
        departmentId: supportDept.id
      }
    });

    console.log('\n✅ Categories created successfully:');
    console.log(`- Network Issues (${itDept.name})`);
    console.log(`- KASDA Support (${supportDept.name})`);
    console.log(`- BSGDirect Support (${supportDept.name})`);

    // List all users to show our test setup
    const users = await prisma.user.findMany({
      include: { department: true },
      orderBy: { role: 'asc' }
    });

    console.log('\n👥 Current users in system:');
    users.forEach(user => {
      console.log(`- ${user.username} (${user.role}) - ${user.department?.name || 'No department'}`);
    });

  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

seedTestData();