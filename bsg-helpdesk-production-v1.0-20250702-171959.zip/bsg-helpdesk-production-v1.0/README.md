# BSG Enterprise Ticketing System - Production Deployment

## 🚀 Quick Start

1. **Extract & Setup**:
   ```bash
   unzip bsg-helpdesk-production-v1.0-*.zip
   cd bsg-helpdesk-production-v1.0
   ```

2. **Automated Deployment**:
   ```bash
   chmod +x deploy.sh
   ./deploy.sh
   ```

3. **Access System**:
   - URL: http://localhost:3000
   - Admin: admin@bsg.co.id / password123

## 📋 What's Included

✅ **Complete SLA Workflow** - Approval-based timer with business hours
✅ **53 BSG Branch Network** - Complete banking infrastructure  
✅ **159 Indonesian Users** - Realistic production data
✅ **Enterprise Service Catalog** - 24+ banking templates
✅ **Advanced Reporting** - Real-time SLA analytics
✅ **Role-Based Access** - Admin/Manager/Technician/User roles

## 🔧 Manual Setup (Alternative)

If automated deployment fails:

```bash
# 1. Install dependencies
npm install
cd frontend && npm install && cd ..

# 2. Configure environment
cp .env.example .env
# Edit .env with your database credentials

# 3. Setup database
npm run db:setup
npm run db:seed:production

# 4. Start system
npm run dev
```

## 📚 Documentation

- **Deployment Guide**: `./DEPLOYMENT.md`
- **System Overview**: `./CLAUDE.md`
- **User Manual**: `./docs/USER_GUIDE.md`

## 🔐 Security

**IMPORTANT**: Change all default passwords immediately after deployment!

- Admin: admin@bsg.co.id
- Manager: utama.manager@bsg.co.id  
- Technician: it.technician@bsg.co.id
- User: utama.user@bsg.co.id

Default password for all: `password123`

## 📞 Support

For technical support and questions:
- Email: support@bsg.co.id
- Documentation: See DEPLOYMENT.md

---

**BSG Enterprise Ticketing System v1.0**  
*Production-Ready Enterprise Solution*
