# BSG Helpdesk Deployment Package

## 🚀 Quick Start

### Windows Users:
1. Ensure Node.js (v18+) and PostgreSQL are installed
2. Run `scripts/deploy-windows.bat`
3. Follow the on-screen instructions

### Linux/macOS Users:
1. Ensure Node.js (v18+) and PostgreSQL are installed
2. Run `scripts/deploy-unix.sh`
3. Follow the on-screen instructions

## 📁 Package Contents

- **frontend/**: React frontend application
- **backend/**: Node.js backend API
- **database/**: PostgreSQL database dump with sample data
- **docs/**: Complete documentation and user credentials
- **scripts/**: Deployment automation scripts

## 🔧 Manual Setup

### 1. Database Setup
```bash
# Create database
createdb ticketing_system_db

# Import data
psql -d ticketing_system_db -f database/bsg-helpdesk-db-dump.sql
```

### 2. Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env with your database credentials
npm run dev
```

### 3. Frontend Setup
```bash
cd frontend
npm install
cp .env.example .env
# Edit .env with your backend URL
npm start
```

## 🔑 Default Credentials

See `docs/TEST-CREDENTIALS.md` for complete user accounts.

**Quick Access:**
- Admin: `admin@bsg.co.id` / `password123`
- Manager: `utama.manager@bsg.co.id` / `password123`
- Technician: `banking.tech@bsg.co.id` / `password123`

## 🏦 Features Included

✅ Complete BSG Banking Branch Network (53 branches)
✅ 159 Realistic Indonesian Users
✅ Comprehensive Service Catalog (221 services)
✅ Advanced Approval Workflows
✅ Real-time Analytics Dashboard
✅ Technician Self-Service Portal
✅ Knowledge Base System
✅ Multi-language Support

## 📞 Support

For technical support, refer to the documentation in the `docs/` folder.
