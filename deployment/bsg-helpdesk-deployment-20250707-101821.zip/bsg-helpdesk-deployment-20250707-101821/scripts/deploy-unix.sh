#!/bin/bash
echo "🚀 Starting BSG Helpdesk Deployment for Unix/Linux/macOS..."

echo "📦 Installing Node.js dependencies..."
cd backend && npm install
cd ../frontend && npm install

echo "🗄️  Setting up database..."
echo "Please ensure PostgreSQL is installed and running"
echo "Run the following commands:"
echo "1. createdb ticketing_system_db"
echo "2. psql -d ticketing_system_db -f ../database/bsg-helpdesk-db-dump.sql"

echo "🔧 Generating Prisma client..."
cd ../backend && npx prisma generate

echo "🚀 Starting services..."
echo "Backend will run on: http://localhost:3001"
echo "Frontend will run on: http://localhost:3000"

read -p "Press Enter to continue..."
