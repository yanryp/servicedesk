// backend/src/types/custom.d.ts

declare module 'bcrypt';
declare module 'jsonwebtoken';
