# Page snapshot

```yaml
- navigation:
  - link "BSG Helpdesk Support Portal":
    - /url: /
  - link "Login to BSG Helpdesk":
    - /url: /login
- main:
  - heading "Welcome to BSG Helpdesk" [level=2]
  - paragraph: Sign in to access the support portal
  - text: Email address
  - textbox "Email address": it.technician@company.com
  - text: Password
  - textbox "Password": tech123
  - button
  - button "Sign in to BSG Helpdesk"
  - paragraph:
    - text: Don't have an account?
    - link "Create one here":
      - /url: /register
```