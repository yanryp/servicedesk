const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function fixApprovalAssignment() {
  console.log('🔧 Fixing Approval Assignment for Ticket #12...\n');

  try {
    // 1. Get ticket #12 and its current approval
    const ticket = await prisma.ticket.findUnique({
      where: { id: 12 },
      include: {
        createdBy: {
          include: {
            unit: true,
            manager: true
          }
        }
      }
    });

    if (!ticket) {
      console.log('❌ Ticket #12 not found');
      return;
    }

    console.log(`📋 Ticket #12: ${ticket.title}`);
    console.log(`   Created by: ${ticket.createdBy?.username} (Unit: ${ticket.createdBy?.unit?.name})`);
    console.log(`   User's manager: ${ticket.createdBy?.manager?.username}`);

    // 2. Get current business approval
    const currentApproval = await prisma.businessApproval.findFirst({
      where: { ticketId: 12 },
      include: {
        businessReviewer: {
          include: { unit: true }
        }
      }
    });

    if (currentApproval) {
      console.log(`   Current reviewer: ${currentApproval.businessReviewer?.username} (${currentApproval.businessReviewer?.email})`);
    }

    // 3. Find the correct manager - the one we've been testing with
    const correctManager = await prisma.user.findUnique({
      where: { email: 'rina.fadilah.manager@bsg.co.id' },
      include: { unit: true }
    });

    if (!correctManager) {
      console.log('❌ rina.fadilah.manager@bsg.co.id not found');
      return;
    }

    console.log(`   Correct manager: ${correctManager.username} (${correctManager.email})`);
    console.log(`   Manager unit: ${correctManager.unit?.name}`);
    console.log(`   isBusinessReviewer: ${correctManager.isBusinessReviewer}`);

    // 4. Update the business approval to assign to the correct manager
    if (currentApproval) {
      console.log('\n🔄 Updating BusinessApproval assignment...');
      
      const updatedApproval = await prisma.businessApproval.update({
        where: { id: currentApproval.id },
        data: {
          businessReviewerId: correctManager.id
        },
        include: {
          businessReviewer: true,
          ticket: true
        }
      });

      console.log(`✅ Updated BusinessApproval #${updatedApproval.id}`);
      console.log(`   New reviewer: ${updatedApproval.businessReviewer?.username}`);
      console.log(`   For ticket: #${updatedApproval.ticket?.id} - ${updatedApproval.ticket?.title}`);
    }

    // 5. Verify the fix by checking the v2/tickets/pending-approvals endpoint logic
    console.log('\n🔍 Verifying fix - checking pending approvals for rina.fadilah.manager@bsg.co.id...');
    
    const pendingApprovals = await prisma.businessApproval.findMany({
      where: {
        businessReviewerId: correctManager.id,
        approvalStatus: 'pending'
      },
      include: {
        ticket: {
          include: {
            createdBy: {
              include: { unit: true }
            }
          }
        },
        businessReviewer: {
          include: { unit: true }
        }
      }
    });

    console.log(`Found ${pendingApprovals.length} pending approvals for ${correctManager.username}:`);
    pendingApprovals.forEach(approval => {
      console.log(`  - Ticket #${approval.ticket?.id}: ${approval.ticket?.title}`);
      console.log(`    Status: ${approval.approvalStatus}`);
      console.log(`    Created by: ${approval.ticket?.createdBy?.username} from ${approval.ticket?.createdBy?.unit?.name}`);
    });

  } catch (error) {
    console.error('Error fixing approval assignment:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixApprovalAssignment();