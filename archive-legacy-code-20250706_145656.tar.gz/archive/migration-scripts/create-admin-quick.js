const { exec } = require('child_process');
const path = require('path');

// Run from backend directory
const backendDir = path.join(__dirname, 'backend');

const createAdminScript = `
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function createAdmin() {
  try {
    // Check if admin exists
    const existing = await prisma.user.findUnique({
      where: { email: 'admin@company.com' }
    });

    if (existing) {
      console.log('✅ Admin user already exists');
      return;
    }

    // Create admin
    const hashedPassword = await bcrypt.hash('admin123', 10);
    
    await prisma.user.create({
      data: {
        username: 'admin',
        email: 'admin@company.com',
        passwordHash: hashedPassword,
        role: 'admin',
        departmentId: 1,
        unitId: 1,
        isAvailable: true,
        workloadCapacity: 20,
      }
    });

    console.log('✅ Admin user created: admin@company.com / admin123');
  } catch (error) {
    console.error('❌ Error:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

createAdmin();
`;

// Write the script to backend directory
require('fs').writeFileSync(path.join(backendDir, 'create-admin-temp.js'), createAdminScript);

// Execute it
exec('cd backend && node create-admin-temp.js', (error, stdout, stderr) => {
  if (error) {
    console.error(`❌ Error: ${error.message}`);
    return;
  }
  if (stderr) {
    console.error(`❌ Stderr: ${stderr}`);
    return;
  }
  console.log(stdout);
  
  // Clean up
  require('fs').unlinkSync(path.join(backendDir, 'create-admin-temp.js'));
});