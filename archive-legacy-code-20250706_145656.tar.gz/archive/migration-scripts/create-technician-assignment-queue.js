const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function createTechnicianAssignmentQueue() {
  console.log('🔧 Creating Technician Assignment Queue System...\n');

  try {
    // 1. Show current state of approved, unassigned tickets
    console.log('1. CURRENT APPROVED, UNASSIGNED TICKETS:');
    
    const availableTickets = await prisma.ticket.findMany({
      where: {
        status: 'open',
        assignedToUserId: null, // Not assigned yet
        businessApproval: {
          approvalStatus: 'approved'
        }
      },
      include: {
        createdBy: {
          include: { unit: true }
        },
        businessApproval: {
          include: { businessReviewer: true }
        },
        template: true,
        serviceItem: true
      }
    });

    console.log(`Found ${availableTickets.length} tickets available for assignment:`);
    
    availableTickets.forEach(ticket => {
      // Determine which department should handle this ticket
      let recommendedDept = 'Unknown';
      
      if (ticket.title?.toLowerCase().includes('kasda') || 
          ticket.template?.name?.toLowerCase().includes('kasda') ||
          ticket.serviceItem?.name?.toLowerCase().includes('kasda')) {
        recommendedDept = 'Dukungan dan Layanan (KASDA Support)';
      } else if (ticket.title?.toLowerCase().includes('elos') ||
                 ticket.title?.toLowerCase().includes('network') ||
                 ticket.title?.toLowerCase().includes('it')) {
        recommendedDept = 'Information Technology';
      } else {
        recommendedDept = 'General Support';
      }
      
      console.log(`\n  🎫 Ticket #${ticket.id}: ${ticket.title}`);
      console.log(`     Created by: ${ticket.createdBy?.username} (${ticket.createdBy?.unit?.name})`);
      console.log(`     Approved by: ${ticket.businessApproval?.businessReviewer?.username}`);
      console.log(`     Category: ${ticket.template?.name || ticket.serviceItem?.name || 'General'}`);
      console.log(`     Recommended for: ${recommendedDept}`);
    });

    // 2. Demonstrate KASDA ticket assignment to Dukungan dan Layanan technician
    console.log('\n\n2. TESTING KASDA TICKET ASSIGNMENT:');
    
    const kasdaTicket = availableTickets.find(t => 
      t.title?.toLowerCase().includes('kasda') && t.id === 12
    );
    
    if (kasdaTicket) {
      console.log(`\n🎯 Assigning Ticket #${kasdaTicket.id} to Dukungan dan Layanan technician...`);
      
      // Find Dukungan dan Layanan technician
      const bankingTech = await prisma.user.findUnique({
        where: { email: 'banking.tech@company.com' },
        include: { department: true }
      });

      if (bankingTech) {
        console.log(`   Found technician: ${bankingTech.username} (${bankingTech.department?.name})`);
        
        // Assign the ticket
        const updatedTicket = await prisma.ticket.update({
          where: { id: kasdaTicket.id },
          data: {
            assignedToUserId: bankingTech.id,
            status: 'assigned' // Change status to assigned
          },
          include: {
            assignedTo: {
              include: { department: true }
            }
          }
        });

        console.log(`   ✅ Ticket #${updatedTicket.id} assigned successfully!`);
        console.log(`   New status: ${updatedTicket.status}`);
        console.log(`   Assigned to: ${updatedTicket.assignedTo?.username} (${updatedTicket.assignedTo?.department?.name})`);

        // Update technician workload
        await prisma.user.update({
          where: { id: bankingTech.id },
          data: {
            currentWorkload: bankingTech.currentWorkload + 1
          }
        });
        
        console.log(`   Updated technician workload: ${bankingTech.currentWorkload} → ${bankingTech.currentWorkload + 1}`);
      }
    }

    // 3. Show final state
    console.log('\n\n3. FINAL STATE - TICKETS NOW ASSIGNED:');
    
    const assignedTickets = await prisma.ticket.findMany({
      where: {
        status: 'assigned',
        assignedToUserId: { not: null }
      },
      include: {
        assignedTo: {
          include: { department: true }
        },
        createdBy: {
          include: { unit: true }
        }
      }
    });

    console.log(`Found ${assignedTickets.length} assigned tickets:`);
    assignedTickets.forEach(ticket => {
      console.log(`\n  ✅ Ticket #${ticket.id}: ${ticket.title}`);
      console.log(`     Status: ${ticket.status}`);
      console.log(`     Created by: ${ticket.createdBy?.username} (${ticket.createdBy?.unit?.name})`);
      console.log(`     Assigned to: ${ticket.assignedTo?.username} (${ticket.assignedTo?.department?.name})`);
    });

    console.log('\n🎉 Technician Assignment Queue System Created Successfully!');
    console.log('\nNext Steps for UI:');
    console.log('1. Technicians can see assigned tickets in "My Tickets"');
    console.log('2. Available tickets shown in assignment queue');
    console.log('3. Self-assignment or automatic routing based on skills');

  } catch (error) {
    console.error('Error creating technician assignment queue:', error);
  } finally {
    await prisma.$disconnect();
  }
}

createTechnicianAssignmentQueue();