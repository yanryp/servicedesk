const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function fixApprovalWorkflow() {
  try {
    console.log('🔧 Fixing approval workflow...\n');
    
    // 1. Assign admin as manager for test_requester
    console.log('👤 Assigning admin as manager for test_requester...');
    const updatedUser = await prisma.user.update({
      where: { username: 'test_requester' },
      data: { managerId: 1 } // admin user ID
    });
    console.log(`✅ test_requester now has manager: ${updatedUser.managerId}\n`);
    
    // 2. Create missing BusinessApproval record for ticket #2
    console.log('📋 Creating BusinessApproval record for ticket #2...');
    const businessApproval = await prisma.businessApproval.create({
      data: {
        ticketId: 2,
        businessReviewerId: 1, // admin user ID
        approvalStatus: 'pending',
        businessComments: 'Pending manager approval for OLIBS user registration request'
      }
    });
    console.log(`✅ BusinessApproval created with ID: ${businessApproval.id}\n`);
    
    // 3. Verify the fix
    console.log('🔍 Verifying the fix...');
    
    const ticket = await prisma.ticket.findUnique({
      where: { id: 2 },
      include: {
        createdBy: {
          select: {
            username: true,
            managerId: true,
            manager: {
              select: {
                username: true,
                role: true
              }
            }
          }
        },
        businessApproval: {
          include: {
            businessReviewer: {
              select: {
                username: true,
                role: true
              }
            }
          }
        }
      }
    });
    
    if (ticket) {
      console.log(`📋 Ticket #2: ${ticket.title}`);
      console.log(`   Status: ${ticket.status}`);
      console.log(`   Creator: ${ticket.createdBy.username}`);
      console.log(`   Creator Manager: ${ticket.createdBy.manager?.username || 'None'}`);
      console.log(`   Business Approval Status: ${ticket.businessApproval?.approvalStatus || 'None'}`);
      console.log(`   Assigned Reviewer: ${ticket.businessApproval?.businessReviewer?.username || 'None'}`);
    }
    
    // 4. Test manager dashboard query
    console.log('\n🔧 Testing manager dashboard query...');
    const pendingForApproval = await prisma.ticket.findMany({
      where: {
        status: 'pending_approval',
        requiresBusinessApproval: true,
        businessApproval: {
          approvalStatus: 'pending'
        }
      },
      include: {
        createdBy: {
          select: {
            username: true
          }
        },
        businessApproval: {
          select: {
            approvalStatus: true,
            businessReviewerId: true
          }
        }
      }
    });
    
    console.log(`✅ Found ${pendingForApproval.length} tickets pending approval`);
    pendingForApproval.forEach(ticket => {
      console.log(`   - Ticket #${ticket.id}: ${ticket.title}`);
      console.log(`     Creator: ${ticket.createdBy.username}`);
      console.log(`     Approval Status: ${ticket.businessApproval?.approvalStatus}`);
    });
    
    console.log('\n✨ Approval workflow should now work correctly!');
    console.log('📝 Next steps:');
    console.log('   1. Refresh the Manager Dashboard in the browser');
    console.log('   2. The ticket should now appear in pending approvals');
    console.log('   3. Test the approval process by approving the ticket');
    
  } catch (error) {
    console.error('❌ Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixApprovalWorkflow();