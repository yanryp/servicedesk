const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function fixBranchUserPasswords() {
  console.log('🔐 Fixing passwords for all branch users...\n');
  
  const users = [
    'utama.user@company.com',
    'utama.manager@company.com', 
    'kotamobagu.user@company.com',
    'kotamobagu.manager@company.com',
    'it.technician@company.com',
    'banking.tech@company.com',
    'admin@company.com'
  ];
  
  const passwordHash = await bcrypt.hash('password123', 10);
  
  for (const email of users) {
    try {
      const user = await prisma.user.findUnique({
        where: { email }
      });
      
      if (user) {
        await prisma.user.update({
          where: { id: user.id },
          data: { passwordHash }
        });
        console.log(`✅ Fixed password for: ${email}`);
      } else {
        console.log(`❌ User not found: ${email}`);
      }
    } catch (error) {
      console.log(`❌ Error fixing password for ${email}:`, error.message);
    }
  }
  
  console.log('\n🎯 All user passwords set to: password123');
}

fixBranchUserPasswords().catch(console.error).finally(() => process.exit());