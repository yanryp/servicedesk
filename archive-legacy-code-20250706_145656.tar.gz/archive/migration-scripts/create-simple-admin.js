const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function createSimpleAdmin() {
  try {
    // Check if admin already exists
    const existingAdmin = await prisma.user.findUnique({
      where: { email: 'admin@company.com' }
    });

    if (existingAdmin) {
      console.log('✅ Admin user already exists');
      return;
    }

    // Hash password
    const hashedPassword = await bcrypt.hash('admin123', 10);

    // Create admin user
    await prisma.user.create({
      data: {
        username: 'admin',
        email: 'admin@company.com',
        passwordHash: hashedPassword,
        role: 'admin',
        departmentId: 1, // Assuming IT department with ID 1 exists
        unitId: 1, // Assuming a unit exists
        isAvailable: true,
        workloadCapacity: 20,
      }
    });

    console.log('✅ Admin user created successfully');
    console.log('📧 Email: admin@company.com');
    console.log('🔑 Password: admin123');

  } catch (error) {
    console.error('❌ Error creating admin:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

createSimpleAdmin();