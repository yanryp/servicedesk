const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

// Indonesian names database
const indonesianNames = {
  male: [
    'Budi', 'Ahmad', 'Andi', 'Dedi', 'Eko', 'Fajar', 'Hendra', 'Indra', 'Joko', 'Kurnia',
    'Lukman', 'Muhammad', 'Nur', 'Oka', 'Putra', 'Rizki', 'Sandi', 'Toni', 'Umar', 'Wahyu',
    'Yudi', 'Zaki', 'Agus', 'Bayu', 'Candra', 'Dimas', 'Gilang', 'Hadi', 'Ivan', 'Jefri',
    'Kevin', 'Luthfi', 'Mahendra', 'Nanda', 'Oscar', 'Prayogo', 'Qori', 'Raffi', 'Satrio', 'Taufik',
    'Ucok', 'Victor', 'Willy', 'Yanto', 'Zulkifli', 'Adrian', 'Bambang', 'Chandra', 'Daniel', 'Edward',
    'Ferry', 'Gunawan', 'Hasan', 'Irwan', 'Januar', 'Kristian', 'Leonard', 'Mario', 'Nathan', 'Oktavian'
  ],
  female: [
    'Sari', 'Dewi', 'Rina', 'Maya', 'Lina', 'Fitri', 'Indah', 'Ratna', 'Novi', 'Putri',
    'Wulan', 'Yani', 'Rini', 'Mega', 'Tari', 'Diah', 'Eka', 'Fina', 'Gita', 'Hesti',
    'Ika', 'Jihan', 'Kirana', 'Laras', 'Mira', 'Nina', 'Okta', 'Prita', 'Qory', 'Rahma',
    'Silva', 'Tika', 'Ulfa', 'Vera', 'Widi', 'Yuli', 'Zahra', 'Ayu', 'Bella', 'Citra',
    'Diana', 'Elsa', 'Farah', 'Grace', 'Hana', 'Intan', 'Jasmine', 'Karina', 'Lestari', 'Monica',
    'Nabila', 'Olivia', 'Priska', 'Queen', 'Rosa', 'Sinta', 'Tiara', 'Umi', 'Vina', 'Winda'
  ],
  lastName: [
    'Santoso', 'Wijaya', 'Kurniawan', 'Sari', 'Putra', 'Dewi', 'Lestari', 'Pratama', 'Wati', 'Saputra',
    'Maharani', 'Permana', 'Handayani', 'Nugroho', 'Rahayu', 'Setiawan', 'Anggraini', 'Gunawan', 'Susanti', 'Hartono',
    'Fitriani', 'Wahyudi', 'Safitri', 'Purnomo', 'Utami', 'Kusuma', 'Andriani', 'Syahputra', 'Pertiwi', 'Mahendra',
    'Damayanti', 'Adiputra', 'Cahyani', 'Trianto', 'Susilawati', 'Hakim', 'Nurjanah', 'Krisna', 'Melati', 'Satria',
    'Kartika', 'Firmansyah', 'Rosyadi', 'Maulana', 'Fadilah', 'Wibowo', 'Yulianti', 'Pradana', 'Sukmawardani', 'Ramadhan'
  ]
};

// Generate realistic Indonesian name
function generateIndonesianName() {
  const isMale = Math.random() > 0.5;
  const firstNames = isMale ? indonesianNames.male : indonesianNames.female;
  const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  const lastName = indonesianNames.lastName[Math.floor(Math.random() * indonesianNames.lastName.length)];
  
  return {
    fullName: `${firstName} ${lastName}`,
    firstName,
    lastName,
    gender: isMale ? 'male' : 'female'
  };
}

// Generate email from name
function generateEmail(name, role, branchCode) {
  const cleanName = name.toLowerCase().replace(/\s+/g, '.');
  return `${cleanName}.${role}@bsg.co.id`;
}

// Create username from name
function generateUsername(name, role) {
  const cleanName = name.toLowerCase().replace(/\s+/g, '.');
  return `${cleanName}.${role}`;
}

async function createRealisticUsers() {
  console.log('👥 CREATING REALISTIC INDONESIAN USERS FOR ALL BRANCHES');
  console.log('═'.repeat(70));
  
  try {
    // Get all branches
    const branches = await prisma.unit.findMany({
      where: { 
        unitType: { in: ['branch', 'sub_branch'] },
        isActive: true 
      },
      orderBy: [
        { unitType: 'asc' }, // branch first, then sub_branch
        { sortOrder: 'asc' }
      ]
    });

    console.log(`📊 Found ${branches.length} branches to create users for`);

    // Check existing users to avoid conflicts
    const existingUsers = await prisma.user.findMany({
      where: {
        email: { contains: '@bsg.co.id' }
      }
    });

    console.log(`👤 Found ${existingUsers.length} existing @bsg.co.id users`);

    // Hash password for all new users
    const defaultPassword = 'password123';
    const passwordHash = await bcrypt.hash(defaultPassword, 10);
    console.log('🔐 Password hash prepared for all users');

    let createdUsers = [];
    let skippedBranches = [];

    console.log('\n👨‍💼 Creating managers and users for each branch...\n');

    for (const branch of branches) {
      console.log(`🏢 Processing ${branch.name} (${branch.code})...`);

      try {
        // Generate names for manager and 2 users
        const managerName = generateIndonesianName();
        const user1Name = generateIndonesianName();
        const user2Name = generateIndonesianName();

        // Create branch manager
        const managerEmail = generateEmail(managerName.fullName, 'manager', branch.code);
        const managerUsername = `${managerName.firstName.toLowerCase()}.${managerName.lastName.toLowerCase()}.manager.${branch.code.toLowerCase()}`;

        // Check if manager already exists
        const existingManager = existingUsers.find(u => u.email === managerEmail);
        if (!existingManager) {
          const manager = await prisma.user.create({
            data: {
              username: managerUsername,
              email: managerEmail,
              passwordHash: passwordHash,
              role: 'manager',
              unit: {
                connect: { id: branch.id }
              },
              isBusinessReviewer: true, // All branch managers can approve
              isAvailable: true,
              currentWorkload: 0,
              workloadCapacity: 10,
            }
          });

          createdUsers.push({
            ...manager,
            branchName: branch.name,
            role: 'manager'
          });

          console.log(`  ✅ Manager: ${managerName.fullName} (${managerEmail})`);
        } else {
          console.log(`  ⏭️ Manager exists: ${existingManager.email}`);
        }

        // Create user 1
        const user1Email = generateEmail(user1Name.fullName, 'user', branch.code);
        const user1Username = `${user1Name.firstName.toLowerCase()}.${user1Name.lastName.toLowerCase()}.user.${branch.code.toLowerCase()}`;

        const existingUser1 = existingUsers.find(u => u.email === user1Email);
        if (!existingUser1) {
          const user1 = await prisma.user.create({
            data: {
              username: user1Username,
              email: user1Email,
              passwordHash: passwordHash,
              role: 'requester',
              unit: {
                connect: { id: branch.id }
              },
              manager: {
                connect: { id: existingManager ? existingManager.id : createdUsers[createdUsers.length - 1].id }
              },
              isAvailable: true,
              currentWorkload: 0,
              workloadCapacity: 5,
            }
          });

          createdUsers.push({
            ...user1,
            branchName: branch.name,
            role: 'requester'
          });

          console.log(`  ✅ User 1: ${user1Name.fullName} (${user1Email})`);
        } else {
          console.log(`  ⏭️ User 1 exists: ${existingUser1.email}`);
        }

        // Create user 2
        const user2Email = generateEmail(user2Name.fullName, 'staff', branch.code);
        const user2Username = `${user2Name.firstName.toLowerCase()}.${user2Name.lastName.toLowerCase()}.staff.${branch.code.toLowerCase()}`;

        const existingUser2 = existingUsers.find(u => u.email === user2Email);
        if (!existingUser2) {
          const user2 = await prisma.user.create({
            data: {
              username: user2Username,
              email: user2Email,
              passwordHash: passwordHash,
              role: 'requester',
              unit: {
                connect: { id: branch.id }
              },
              managerId: existingManager ? existingManager.id : createdUsers.find(u => u.branchName === branch.name && u.role === 'manager').id,
              isAvailable: true,
              currentWorkload: 0,
              workloadCapacity: 5,
            }
          });

          createdUsers.push({
            ...user2,
            branchName: branch.name,
            role: 'requester'
          });

          console.log(`  ✅ User 2: ${user2Name.fullName} (${user2Email})`);
        } else {
          console.log(`  ⏭️ User 2 exists: ${existingUser2.email}`);
        }

        console.log(`  🎯 Completed ${branch.name}\n`);

      } catch (error) {
        console.error(`  ❌ Error creating users for ${branch.name}:`, error.message);
        skippedBranches.push(branch.name);
      }
    }

    // Summary
    console.log('\n📊 USER CREATION SUMMARY:');
    console.log('═'.repeat(50));

    const finalUsers = await prisma.user.findMany({
      where: {
        email: { contains: '@bsg.co.id' }
      },
      include: {
        unit: true
      },
      orderBy: { email: 'asc' }
    });

    // Group users by role
    const managers = finalUsers.filter(u => u.role === 'manager');
    const requesters = finalUsers.filter(u => u.role === 'requester');

    console.log(`👥 Total @bsg.co.id users: ${finalUsers.length}`);
    console.log(`   • Managers: ${managers.length}`);
    console.log(`   • Requesters: ${requesters.length}`);

    // Branch coverage
    const branchesWithUsers = {};
    finalUsers.forEach(user => {
      if (user.unit) {
        branchesWithUsers[user.unit.name] = (branchesWithUsers[user.unit.name] || 0) + 1;
      }
    });

    console.log(`\n🏢 Branch Coverage: ${Object.keys(branchesWithUsers).length}/${branches.length} branches`);

    // Regional distribution
    const regionalUsers = {};
    finalUsers.forEach(user => {
      if (user.unit?.region) {
        regionalUsers[user.unit.region] = (regionalUsers[user.unit.region] || 0) + 1;
      }
    });

    console.log('\n🌍 Regional User Distribution:');
    Object.entries(regionalUsers).forEach(([region, count]) => {
      console.log(`   • ${region}: ${count} users`);
    });

    if (skippedBranches.length > 0) {
      console.log(`\n⚠️ Skipped branches (${skippedBranches.length}):`, skippedBranches.join(', '));
    }

    console.log('\n✅ USER CREATION COMPLETED SUCCESSFULLY!');
    console.log(`🔑 All users password: ${defaultPassword}`);
    console.log('🎯 Ready for workflow testing across all branches');

  } catch (error) {
    console.error('❌ Error creating users:', error);
    throw error;
  }
}

createRealisticUsers().catch(console.error).finally(() => process.exit());