#!/usr/bin/env node

/**
 * Create Proper ITIL-Based Service Catalog Structure
 * 
 * This script creates the proper service catalog structure following ITIL best practices
 * with channel differentiation (BSGTouch, ATM, SMS Banking, KASDA, etc.) and transaction types
 * (Transfer, Payment, Purchase, User Management) as emphasized by the user.
 */

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

/**
 * ITIL Service Catalog Structure with Channel Differentiation
 */
const ITIL_SERVICE_CATALOGS = [
  {
    name: 'Banking Applications - User Management',
    description: 'User registration, modification, and access management across all banking channels',
    serviceType: 'business_service',
    departmentName: 'Information Technology',
    channels: ['BSGTouch', 'ATM', 'SMS Banking', 'OLIBS', 'KASDA', 'BSG Direct', 'XCARD', 'BSG QRIS', 'TellerApp']
  },
  {
    name: 'Claims & Transactions - Transfer Services', 
    description: 'Transfer services across all channels including inter-bank transfers and claims processing',
    serviceType: 'business_service',
    departmentName: 'Information Technology',
    channels: ['BSGTouch', 'ATM', 'SMS Banking', 'BSG Direct', 'BI Fast']
  },
  {
    name: 'Claims & Transactions - Payment Services',
    description: 'Bill payment services across multiple channels (PBB, Samsat, PLN, BPJS, etc.)',
    serviceType: 'business_service', 
    departmentName: 'Information Technology',
    channels: ['BSGTouch', 'ATM', 'SMS Banking', 'TellerApp']
  },
  {
    name: 'Claims & Transactions - Purchase Services',
    description: 'Purchase services including pulsa, tokens, and other retail products',
    serviceType: 'business_service',
    departmentName: 'Information Technology', 
    channels: ['BSGTouch', 'ATM', 'SMS Banking']
  },
  {
    name: 'KASDA Services',
    description: 'Regional government treasury services and KASDA Online system',
    serviceType: 'business_service',
    departmentName: 'Information Technology',
    channels: ['KASDA Online', 'KASDA BUD']
  },
  {
    name: 'Identity & Access Management',
    description: 'Security management, access control, and authentication services',
    serviceType: 'technical_service',
    departmentName: 'Information Technology', 
    channels: ['Domain', 'Security']
  },
  {
    name: 'IT Infrastructure Services',
    description: 'Network, hardware, software maintenance and technical support services',
    serviceType: 'technical_service',
    departmentName: 'Information Technology',
    channels: ['Network', 'Hardware', 'Software', 'Maintenance']
  }
];

/**
 * Parse CSV data and create service items with proper channel organization
 */
async function parseAndCreateServices() {
  console.log('📄 Reading CSV templates...\n');
  
  // Read hd_template.csv (247 services)
  const hdTemplatePath = path.join(__dirname, '..', 'hd_template.csv');
  const hdTemplateData = fs.readFileSync(hdTemplatePath, 'utf-8');
  const allServices = hdTemplateData.split('\n')
    .slice(1) // Skip header
    .filter(line => line.trim())
    .map(line => {
      const [name, description, showToRequester] = line.split(';');
      return {
        name: name?.replace(/^﻿/, ''), // Remove BOM
        description: description || '',
        showToRequester: showToRequester === 'Yes'
      };
    });

  console.log(`Found ${allServices.length} services in hd_template.csv`);

  // Read template.csv (24 services with custom fields)
  const templatePath = path.join(__dirname, '..', 'template.csv');
  let servicesWithFields = [];
  
  if (fs.existsSync(templatePath)) {
    const templateData = fs.readFileSync(templatePath, 'utf-8');
    const templateLines = templateData.split('\n').slice(1).filter(line => line.trim());
    servicesWithFields = templateLines.map(line => {
      const cols = line.split(';');
      return cols[0]?.replace(/^﻿/, ''); // Just get service name
    });
    console.log(`Found ${servicesWithFields.length} services with custom fields in template.csv`);
  }

  return { allServices, servicesWithFields };
}

/**
 * Categorize services by channel and transaction type
 */
function categorizeServices(services) {
  const categories = {
    userManagement: [],
    transferServices: [], 
    paymentServices: [],
    purchaseServices: [],
    kasdaServices: [],
    identityAccess: [],
    itInfra: []
  };

  services.forEach(service => {
    const name = service.name.toLowerCase();
    
    // User Management Services (across all channels)
    if (name.includes('pendaftaran user') || name.includes('mutasi user') || 
        name.includes('perubahan user') || name.includes('reset password') ||
        name.includes('buka blokir') || name.includes('user expire') ||
        name.includes('perpanjang masa berlaku')) {
      categories.userManagement.push(service);
    }
    // Transfer Services 
    else if (name.includes('transfer') || name.includes('penarikan') || 
             name.includes('klaim') && (name.includes('transfer') || name.includes('penarikan'))) {
      categories.transferServices.push(service);
    }
    // Payment Services
    else if (name.includes('pembayaran') || name.includes('tagihan') ||
             (name.includes('pbb') || name.includes('samsat') || name.includes('pln') || 
              name.includes('bpjs') || name.includes('citilink') || name.includes('bigtv') ||
              name.includes('pstn') || name.includes('kartu halo'))) {
      categories.paymentServices.push(service);
    }
    // Purchase Services  
    else if (name.includes('pembelian') || name.includes('pulsa') || name.includes('token')) {
      categories.purchaseServices.push(service);
    }
    // KASDA Services
    else if (name.includes('kasda')) {
      categories.kasdaServices.push(service);
    }
    // Identity & Access
    else if (name.includes('domain') || name.includes('keamanan') || name.includes('security')) {
      categories.identityAccess.push(service);
    }
    // IT Infrastructure (everything else)
    else {
      categories.itInfra.push(service);
    }
  });

  return categories;
}

/**
 * Create service catalogs and items with proper ITIL structure
 */
async function createITILStructure() {
  console.log('🏗️  Creating ITIL Service Catalog Structure...\n');

  try {
    // Get IT department
    const itDept = await prisma.department.findFirst({
      where: { name: 'Information Technology' }
    });

    if (!itDept) {
      throw new Error('Information Technology department not found');
    }

    // Parse services from CSV
    const { allServices, servicesWithFields } = await parseAndCreateServices();
    const categorizedServices = categorizeServices(allServices);

    console.log('📊 Service Distribution:');
    Object.entries(categorizedServices).forEach(([category, services]) => {
      console.log(`  ${category}: ${services.length} services`);
    });
    console.log('');

    // Create service catalogs
    for (const catalogConfig of ITIL_SERVICE_CATALOGS) {
      console.log(`📁 Creating catalog: ${catalogConfig.name}`);
      
      // Create or update service catalog
      const catalog = await prisma.serviceCatalog.upsert({
        where: { 
          departmentId_name: {
            departmentId: itDept.id,
            name: catalogConfig.name
          }
        },
        update: {
          description: catalogConfig.description,
          serviceType: catalogConfig.serviceType,
          isActive: true
        },
        create: {
          name: catalogConfig.name,
          description: catalogConfig.description,
          serviceType: catalogConfig.serviceType,
          departmentId: itDept.id,
          isActive: true
        }
      });

      // Add service items based on category
      let servicesToAdd = [];
      
      if (catalogConfig.name.includes('User Management')) {
        servicesToAdd = categorizedServices.userManagement;
      } else if (catalogConfig.name.includes('Transfer Services')) {
        servicesToAdd = categorizedServices.transferServices;
      } else if (catalogConfig.name.includes('Payment Services')) {
        servicesToAdd = categorizedServices.paymentServices;
      } else if (catalogConfig.name.includes('Purchase Services')) {
        servicesToAdd = categorizedServices.purchaseServices;
      } else if (catalogConfig.name.includes('KASDA Services')) {
        servicesToAdd = categorizedServices.kasdaServices;
      } else if (catalogConfig.name.includes('Identity & Access')) {
        servicesToAdd = categorizedServices.identityAccess;
      } else if (catalogConfig.name.includes('IT Infrastructure')) {
        servicesToAdd = categorizedServices.itInfra;
      }

      console.log(`  Adding ${servicesToAdd.length} service items...`);

      // Create service items
      for (const service of servicesToAdd) {
        try {
          await prisma.serviceItem.upsert({
            where: { 
              serviceCatalogId_name: {
                serviceCatalogId: catalog.id,
                name: service.name
              }
            },
            update: {
              description: service.description,
              isActive: service.showToRequester
            },
            create: {
              name: service.name,
              description: service.description,
              serviceCatalogId: catalog.id,
              isActive: service.showToRequester,
              sortOrder: 0
            }
          });
        } catch (error) {
          console.warn(`    ⚠️  Warning: Could not create service item "${service.name}": ${error.message}`);
        }
      }

      console.log(`  ✅ Created catalog "${catalogConfig.name}" with ${servicesToAdd.length} services\n`);
    }

    // Clean up old structure - move misplaced services
    console.log('🧹 Cleaning up old catalog structure...');
    
    // Move payment/transfer services from "Hardware & Software" to proper catalogs
    const hardwareCatalog = await prisma.serviceCatalog.findFirst({
      where: { name: 'Hardware & Software' },
      include: { serviceItems: true }
    });

    if (hardwareCatalog) {
      const transferCatalog = await prisma.serviceCatalog.findFirst({
        where: { name: 'Claims & Transactions - Transfer Services' }
      });
      
      const paymentCatalog = await prisma.serviceCatalog.findFirst({
        where: { name: 'Claims & Transactions - Payment Services' }
      });

      const purchaseCatalog = await prisma.serviceCatalog.findFirst({
        where: { name: 'Claims & Transactions - Purchase Services' }
      });

      // Move services to proper catalogs
      for (const item of hardwareCatalog.serviceItems) {
        const name = item.name.toLowerCase();
        
        if (name.includes('transfer') || name.includes('penarikan')) {
          if (transferCatalog) {
            await prisma.serviceItem.update({
              where: { id: item.id },
              data: { serviceCatalogId: transferCatalog.id }
            });
            console.log(`  ➡️  Moved "${item.name}" to Transfer Services`);
          }
        } else if (name.includes('pembayaran') || name.includes('tagihan')) {
          if (paymentCatalog) {
            await prisma.serviceItem.update({
              where: { id: item.id },
              data: { serviceCatalogId: paymentCatalog.id }
            });
            console.log(`  ➡️  Moved "${item.name}" to Payment Services`);
          }
        } else if (name.includes('pembelian') || name.includes('pulsa') || name.includes('token')) {
          if (purchaseCatalog) {
            await prisma.serviceItem.update({
              where: { id: item.id },
              data: { serviceCatalogId: purchaseCatalog.id }
            });
            console.log(`  ➡️  Moved "${item.name}" to Purchase Services`);
          }
        }
      }
    }

    console.log('\n✅ ITIL Service Catalog Structure Created Successfully!');
    
    // Final verification
    console.log('\n📊 Final Structure Verification:');
    const finalCatalogs = await prisma.serviceCatalog.findMany({
      include: {
        serviceItems: true,
        _count: {
          select: { serviceItems: true }
        }
      },
      orderBy: { name: 'asc' }
    });

    finalCatalogs.forEach(catalog => {
      console.log(`  📁 ${catalog.name}: ${catalog._count.serviceItems} services`);
    });

    const totalServices = finalCatalogs.reduce((sum, cat) => sum + cat._count.serviceItems, 0);
    console.log(`\n📈 Total Services: ${totalServices} (Target: 247 from CSV)`);

  } catch (error) {
    console.error('❌ Error creating ITIL structure:', error);
    throw error;
  }
}

// Execute the script
async function main() {
  try {
    await createITILStructure();
  } catch (error) {
    console.error('Fatal error:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

if (require.main === module) {
  main();
}

module.exports = { createITILStructure };